"""
PaperBroker Client - Python client for algorithmic trading via FIX protocol.

This package provides:
    - PaperBrokerClient: Full FIX + REST trading client
    - PaperBrokerRESTClient: REST-only client (Mac compatible)
    - RedisMarketDataClient: Real-time market data via Redis
    - KafkaMarketDataClient: Real-time market data via Kafka

Platform Compatibility:
    - Linux: Full support (PaperBrokerClient)
    - macOS Intel: Full support (may require build tools)
    - macOS Apple Silicon: REST-only mode or use Docker/Rosetta

Example (Full Mode - Linux/Docker):
    >>> from paperbroker import PaperBrokerClient
    >>> client = PaperBrokerClient(...)
    >>> client.connect()

Example (REST-Only Mode - Mac Compatible):
    >>> from paperbroker import PaperBrokerRESTClient
    >>> client = PaperBrokerRESTClient(...)
    >>> client.connect()
"""
import warnings

# Try to import full client (requires QuickFIX)
_QUICKFIX_AVAILABLE = True
try:
    from .client import PaperBrokerClient
    from .config import render_quickfix_cfg
except ImportError as e:
    _QUICKFIX_AVAILABLE = False
    _quickfix_error = str(e)
    
    # Provide placeholder for type hints
    PaperBrokerClient = None  # type: ignore
    render_quickfix_cfg = None  # type: ignore
    
    warnings.warn(
        f"QuickFIX not available: {_quickfix_error}. "
        "FIX trading is disabled. Use PaperBrokerRESTClient for REST-only operations, "
        "or install paperbroker-client in Docker/Rosetta environment for full support.",
        ImportWarning
    )

# Always import REST-only client (no native dependencies)
from .rest_only_client import PaperBrokerRESTClient

# Import event bus and market data (no native dependencies)
from paperbroker.events import EventBus
from paperbroker.market_data import RedisMarketDataClient, QuoteSnapshot

# Export list
__all__ = [
    "PaperBrokerClient",
    "PaperBrokerRESTClient",
    "render_quickfix_cfg",
    "EventBus",
    "RedisMarketDataClient",
    "QuoteSnapshot",
    "is_quickfix_available",
]


def is_quickfix_available() -> bool:
    """
    Check if QuickFIX is available for FIX trading.
    
    Returns:
        True if QuickFIX is installed and working, False otherwise.
    
    Use this to conditionally enable FIX features:
        >>> if is_quickfix_available():
        ...     client = PaperBrokerClient(...)
        ... else:
        ...     client = PaperBrokerRESTClient(...)
    """
    return _QUICKFIX_AVAILABLE
