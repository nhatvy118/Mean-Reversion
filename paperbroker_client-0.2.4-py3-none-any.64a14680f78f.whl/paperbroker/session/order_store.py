"""
SQLite-based order persistence for crash recovery.

Provides durable storage of order state so that active orders
can be recovered and canceled after an unexpected program restart.

Design Principles:
    - **Backward compatible**: OrderStore is optional. If SQLite init
      fails, all methods become silent no-ops (never crash callers).
    - **Thread-safe**: All operations use a dedicated connection per
      thread via check_same_thread=False + internal locking.
    - **Crash-safe**: WAL journal mode + atomic commits.
    - **Zero extra dependencies**: Uses Python stdlib sqlite3.

Usage:
    Store is injected into OrderManager. If ``store=None`` is passed,
    OrderManager works exactly as before (pure in-memory).
"""
import sqlite3
import threading
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional

# Terminal statuses — orders in these states need no recovery
_TERMINAL_STATUSES = frozenset({
    "FILLED", "CANCELED", "REJECTED", "EXPIRED", "DONE_FOR_DAY",
    "Filled", "Canceled", "Rejected", "Expired", "DoneForDay",
    # lowercase variants for safety
    "filled", "canceled", "rejected", "expired",
})

_SCHEMA_VERSION = 1

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS orders (
    cl_ord_id     TEXT PRIMARY KEY,
    order_id      TEXT,
    symbol        TEXT NOT NULL,
    exchange      TEXT NOT NULL,
    side          TEXT NOT NULL,
    qty           INTEGER NOT NULL,
    price         REAL NOT NULL,
    ord_type      TEXT NOT NULL DEFAULT 'LIMIT',
    status        TEXT NOT NULL,
    sub_account   TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
"""

_CREATE_META = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""

_IDX_STATUS = (
    "CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);"
)


class OrderStore:
    """
    Durable SQLite store for order state.

    All public methods are **fail-safe**: if the database is
    unavailable or a write fails, the error is logged but never
    propagated.  This guarantees that enabling persistence cannot
    break existing order flow.

    Thread Safety:
        Safe for concurrent use from multiple threads. Internal
        locking serialises writes; reads use WAL for concurrency.
    """

    def __init__(
        self,
        db_path: str = "orders.db",
        logger: Optional[logging.Logger] = None,
    ):
        self._logger = logger or logging.getLogger(__name__)
        self._lock = threading.Lock()
        self._conn: Optional[sqlite3.Connection] = None
        self._available = False

        try:
            self._conn = sqlite3.connect(
                db_path,
                check_same_thread=False,
                timeout=5.0,
            )
            self._conn.execute("PRAGMA journal_mode=WAL;")
            self._conn.execute("PRAGMA synchronous=NORMAL;")
            self._conn.execute(_CREATE_TABLE)
            self._conn.execute(_CREATE_META)
            self._conn.execute(_IDX_STATUS)
            # Store schema version for future migrations
            self._conn.execute(
                "INSERT OR IGNORE INTO meta(key, value) VALUES (?, ?)",
                ("schema_version", str(_SCHEMA_VERSION)),
            )
            self._conn.commit()
            self._available = True
            self._logger.info(
                f"[OrderStore] Initialized SQLite store: {db_path}"
            )
        except Exception as e:
            self._logger.warning(
                f"[OrderStore] Failed to initialize SQLite ({e}). "
                "Order persistence disabled — operating in memory-only mode."
            )

    # ------------------------------------------------------------------
    # Public API — all fail-safe
    # ------------------------------------------------------------------

    @property
    def available(self) -> bool:
        """Whether the store is operational."""
        return self._available

    def persist_order(
        self,
        cl_ord_id: str,
        info: dict,
        status: str = "PendingNew",
        sub_account: Optional[str] = None,
    ) -> None:
        """Save a newly placed order."""
        if not self._available:
            return
        now = datetime.now(timezone.utc).isoformat()
        try:
            with self._lock:
                self._conn.execute(
                    """
                    INSERT OR REPLACE INTO orders
                        (cl_ord_id, symbol, exchange, side, qty, price,
                         ord_type, status, sub_account, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        cl_ord_id,
                        info.get("symbol", ""),
                        info.get("exchange", ""),
                        info.get("side", ""),
                        info.get("qty", 0),
                        info.get("price", 0.0),
                        info.get("ord_type", "LIMIT"),
                        status,
                        sub_account,
                        now,
                        now,
                    ),
                )
                self._conn.commit()
        except Exception as e:
            self._logger.warning(
                f"[OrderStore] persist_order failed for {cl_ord_id}: {e}"
            )

    def update_status(
        self,
        cl_ord_id: str,
        status: str,
        order_id: Optional[str] = None,
    ) -> None:
        """Update order status (and optionally the exchange OrderID)."""
        if not self._available:
            return
        now = datetime.now(timezone.utc).isoformat()
        try:
            with self._lock:
                if order_id is not None:
                    self._conn.execute(
                        """
                        UPDATE orders
                           SET status = ?, order_id = ?, updated_at = ?
                         WHERE cl_ord_id = ?
                        """,
                        (status, order_id, now, cl_ord_id),
                    )
                else:
                    self._conn.execute(
                        """
                        UPDATE orders
                           SET status = ?, updated_at = ?
                         WHERE cl_ord_id = ?
                        """,
                        (status, now, cl_ord_id),
                    )
                self._conn.commit()
        except Exception as e:
            self._logger.warning(
                f"[OrderStore] update_status failed for {cl_ord_id}: {e}"
            )

    def update_order_id(self, cl_ord_id: str, order_id: str) -> None:
        """Record the exchange-assigned OrderID."""
        if not self._available:
            return
        now = datetime.now(timezone.utc).isoformat()
        try:
            with self._lock:
                self._conn.execute(
                    """
                    UPDATE orders
                       SET order_id = ?, updated_at = ?
                     WHERE cl_ord_id = ?
                    """,
                    (order_id, now, cl_ord_id),
                )
                self._conn.commit()
        except Exception as e:
            self._logger.warning(
                f"[OrderStore] update_order_id failed for {cl_ord_id}: {e}"
            )

    def get_active_orders(self) -> List[Dict]:
        """
        Return all orders that are NOT in a terminal state.

        These are the orders that may still be live on the exchange
        and need attention after a restart.
        """
        if not self._available:
            return []
        try:
            with self._lock:
                cur = self._conn.execute(
                    """
                    SELECT cl_ord_id, order_id, symbol, exchange,
                           side, qty, price, ord_type, status,
                           sub_account, created_at, updated_at
                      FROM orders
                     WHERE status NOT IN ({})
                    """.format(
                        ",".join("?" for _ in _TERMINAL_STATUSES)
                    ),
                    tuple(_TERMINAL_STATUSES),
                )
                cols = [d[0] for d in cur.description]
                return [dict(zip(cols, row)) for row in cur.fetchall()]
        except Exception as e:
            self._logger.warning(
                f"[OrderStore] get_active_orders failed: {e}"
            )
            return []

    def get_order(self, cl_ord_id: str) -> Optional[Dict]:
        """Fetch a single order by ClOrdID."""
        if not self._available:
            return None
        try:
            with self._lock:
                cur = self._conn.execute(
                    """
                    SELECT cl_ord_id, order_id, symbol, exchange,
                           side, qty, price, ord_type, status,
                           sub_account, created_at, updated_at
                      FROM orders
                     WHERE cl_ord_id = ?
                    """,
                    (cl_ord_id,),
                )
                row = cur.fetchone()
                if row is None:
                    return None
                cols = [d[0] for d in cur.description]
                return dict(zip(cols, row))
        except Exception as e:
            self._logger.warning(
                f"[OrderStore] get_order failed for {cl_ord_id}: {e}"
            )
            return None

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None
            self._available = False
