"""
REST-only client for PaperBroker on Mac (Apple Silicon).

This lightweight client provides REST API access without requiring
QuickFIX, making it compatible with macOS ARM64 (M1/M2/M3/M4).

Use this when:
    - You only need account queries (balance, portfolio, orders)
    - You don't need real-time FIX order execution
    - You're running on Apple Silicon and can't install QuickFIX

For full FIX trading capabilities, use Docker or Rosetta 2.

Example:
    >>> from paperbroker.rest_only_client import PaperBrokerRESTClient
    >>> 
    >>> client = PaperBrokerRESTClient(
    ...     rest_base_url="http://api.example.com:9090",
    ...     username="user",
    ...     password="pass",
    ...     default_sub_account="D1"
    ... )
    >>> 
    >>> # Query balance
    >>> balance = client.get_cash_balance()
    >>> print(f"Available: {balance['remainCash']:,.0f}")
    >>> 
    >>> # Get portfolio
    >>> portfolio = client.get_portfolio_by_sub()
    >>> for pos in portfolio.get('positions', []):
    ...     print(f"{pos['symbol']}: {pos['quantity']} @ {pos['avgPrice']}")
"""
from typing import Dict, Any, Optional
from paperbroker.rest.rest_session import RestSession
from paperbroker.sub_account import SubAccountProvider
from paperbroker.logger import get_logger


class PaperBrokerRESTClient:
    """
    Lightweight REST-only client for macOS compatibility.
    
    This client provides REST API operations without depending on
    QuickFIX, making it compatible with Apple Silicon Macs.
    
    Attributes:
        rest_base_url: Base URL for REST API endpoints.
        username: Trading account username.
        default_sub_account: Default sub-account ID.
    
    Note:
        This client does NOT support:
        - Real-time FIX order placement
        - FIX event subscriptions
        - Order cancellation via FIX
        
        For full functionality, use Docker or Rosetta 2 environments.
    """
    
    def __init__(
        self,
        rest_base_url: str,
        username: str,
        password: str,
        default_sub_account: Optional[str] = None,
        log_dir: str = "logs",
        console: bool = False,
    ):
        """
        Initialize REST-only client.
        
        Args:
            rest_base_url: Base URL for REST API (e.g., "http://api.example.com:9090")
            username: Trading account username
            password: Trading account password
            default_sub_account: Default sub-account ID for queries
            log_dir: Directory for log files
            console: Whether to log to console
        """
        self._rest_session = RestSession(rest_base_url)
        self._sub_provider = SubAccountProvider(default_sub_account)
        self._username = username
        self._password = password
        self._logger = get_logger(log_dir, console)
        self._account_id: Optional[str] = None
        
        self._logger.info(
            f"PaperBrokerRESTClient initialized (REST-only mode)",
            extra={"base_url": rest_base_url, "sub_account": default_sub_account}
        )
    
    def connect(self) -> bool:
        """
        Connect and authenticate with REST API.
        
        Returns:
            True if authentication succeeds, False otherwise.
        """
        try:
            self._account_id = self._fetch_account_id()
            if self._account_id:
                self._logger.info(f"Connected successfully. Account ID: {self._account_id}")
                return True
            else:
                self._logger.error("Failed to authenticate")
                return False
        except Exception as e:
            self._logger.error(f"Connection error: {e}")
            return False
    
    def _fetch_account_id(self) -> Optional[str]:
        """Fetch account ID from server."""
        try:
            response = self._rest_session.get(
                "/fix/account",
                params={"username": self._username, "password": self._password}
            )
            if response and response.get("success"):
                return response.get("data", {}).get("fixAccountID")
            return None
        except Exception as e:
            self._logger.error(f"Error fetching account ID: {e}")
            return None
    
    def _ensure_account_id(self) -> str:
        """Ensure account ID is resolved."""
        if not self._account_id:
            self._account_id = self._fetch_account_id()
        if not self._account_id:
            raise RuntimeError("Account ID not resolved. Call connect() first.")
        return self._account_id
    
    def _resolve_sub_account(self, sub_account_id: Optional[str] = None) -> str:
        """Resolve sub-account ID."""
        return sub_account_id or self._sub_provider.current_sub_account() or ""
    
    # =========================================================================
    # Account Queries
    # =========================================================================
    
    def get_cash_balance(self, sub_account_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get available cash balance.
        
        Args:
            sub_account_id: Sub-account ID. Uses default if not specified.
        
        Returns:
            Dict containing:
                - fixAccountID: FIX account identifier
                - subAccountID: Sub-account identifier
                - remainCash: Available cash balance
        """
        account_id = self._ensure_account_id()
        sub = self._resolve_sub_account(sub_account_id)
        
        try:
            response = self._rest_session.get(
                f"/account/{account_id}/balance",
                params={"subAccountId": sub}
            )
            return response if response else {"success": False, "error": "No response"}
        except Exception as e:
            self._logger.error(f"Error getting cash balance: {e}")
            return {"success": False, "error": str(e)}
    
    def get_account_balance(self, sub_account_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get total account balance including margin.
        
        Args:
            sub_account_id: Sub-account ID. Uses default if not specified.
        
        Returns:
            Dict with balance details including equity, margin, etc.
        """
        return self.get_cash_balance(sub_account_id)
    
    def get_portfolio_by_sub(self, sub_account_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get portfolio positions for sub-account.
        
        Args:
            sub_account_id: Sub-account ID. Uses default if not specified.
        
        Returns:
            Dict containing:
                - success: Boolean indicating success
                - positions: List of position objects with:
                    - symbol: Instrument symbol
                    - quantity: Position quantity
                    - avgPrice: Average entry price
                    - currentPrice: Current market price
                    - unrealizedPnL: Unrealized profit/loss
                    - realizedPnL: Realized profit/loss
        """
        account_id = self._ensure_account_id()
        sub = self._resolve_sub_account(sub_account_id)
        
        try:
            response = self._rest_session.get(
                f"/account/{account_id}/portfolio",
                params={"subAccountId": sub}
            )
            return response if response else {"success": False, "positions": []}
        except Exception as e:
            self._logger.error(f"Error getting portfolio: {e}")
            return {"success": False, "error": str(e), "positions": []}
    
    def get_orders(
        self,
        start_date: str,
        end_date: str,
        sub_account_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get historical orders within date range.
        
        Args:
            start_date: Start date in "YYYY-MM-DD" format
            end_date: End date in "YYYY-MM-DD" format
            sub_account_id: Sub-account ID. Uses default if not specified.
        
        Returns:
            Dict containing:
                - success: Boolean indicating success
                - orders: List of order objects
        
        Note:
            Server-side timestamp parsing may cause issues.
            Use get_transactions_by_date() as alternative.
        """
        account_id = self._ensure_account_id()
        sub = self._resolve_sub_account(sub_account_id)
        
        try:
            response = self._rest_session.get(
                f"/account/{account_id}/orders",
                params={
                    "subAccountId": sub,
                    "startDate": start_date,
                    "endDate": end_date
                }
            )
            return response if response else {"success": False, "orders": []}
        except Exception as e:
            self._logger.error(f"Error getting orders: {e}")
            return {"success": False, "error": str(e), "orders": []}
    
    def get_transactions_by_date(
        self,
        start_date: str,
        end_date: str,
        sub_account_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get transaction history within date range.
        
        Args:
            start_date: Start date in "YYYY-MM-DD" format
            end_date: End date in "YYYY-MM-DD" format
            sub_account_id: Sub-account ID. Uses default if not specified.
        
        Returns:
            Dict containing:
                - success: Boolean indicating success
                - transactions: List of transaction objects
        """
        account_id = self._ensure_account_id()
        sub = self._resolve_sub_account(sub_account_id)
        
        try:
            response = self._rest_session.get(
                f"/account/{account_id}/transactions",
                params={
                    "subAccountId": sub,
                    "startDate": start_date,
                    "endDate": end_date
                }
            )
            return response if response else {"success": False, "transactions": []}
        except Exception as e:
            self._logger.error(f"Error getting transactions: {e}")
            return {"success": False, "error": str(e), "transactions": []}
    
    def get_max_placeable(
        self,
        symbol: str,
        price: float,
        side: str,
        sub_account_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Calculate maximum placeable quantity.
        
        Args:
            symbol: Instrument symbol (e.g., "HNXDS:VN30F2511")
            price: Order price
            side: Order side ("BUY" or "SELL")
            sub_account_id: Sub-account ID. Uses default if not specified.
        
        Returns:
            Dict containing:
                - success: Boolean indicating success
                - maxQuantity: Maximum quantity that can be placed
                - marginRequired: Margin required per contract
        """
        account_id = self._ensure_account_id()
        sub = self._resolve_sub_account(sub_account_id)
        
        try:
            response = self._rest_session.get(
                f"/account/{account_id}/max-placeable",
                params={
                    "subAccountId": sub,
                    "symbol": symbol,
                    "price": price,
                    "side": side
                }
            )
            return response if response else {"success": False, "maxQuantity": 0}
        except Exception as e:
            self._logger.error(f"Error getting max placeable: {e}")
            return {"success": False, "error": str(e), "maxQuantity": 0}
    
    # =========================================================================
    # Sub-Account Management
    # =========================================================================
    
    def set_default_sub_account(self, sub_account_id: str) -> None:
        """
        Set the default sub-account for queries.
        
        Args:
            sub_account_id: Sub-account ID to use as default
        """
        self._sub_provider.set_default_sub_account(sub_account_id)
        self._logger.info(f"Default sub-account set to: {sub_account_id}")
    
    def current_sub_account(self) -> Optional[str]:
        """
        Get current active sub-account ID.
        
        Returns:
            Current sub-account ID or None if not set.
        """
        return self._sub_provider.current_sub_account()
    
    # =========================================================================
    # Connection Status
    # =========================================================================
    
    def is_connected(self) -> bool:
        """
        Check if client is connected (has valid account ID).
        
        Returns:
            True if connected, False otherwise.
        """
        return self._account_id is not None
    
    @property
    def account_id(self) -> Optional[str]:
        """Get the resolved account ID."""
        return self._account_id


# Convenience alias
RESTClient = PaperBrokerRESTClient
