"""
Market Data Module - Multiple data source implementations.

Provides real-time market quotes via:
1. Redis - Async pub/sub (recommended for low-latency)
2. Kafka - Async consumer (recommended for reliability)

Both clients provide:
- query() - Get current quote snapshot
- subscribe() - Real-time streaming updates

Example (Redis):
    from paperbroker.market_data import RedisMarketDataClient
    
    async def main():
        client = RedisMarketDataClient(
            host=os.getenv('MARKET_REDIS_HOST'),
            password=os.getenv('MARKET_REDIS_PASSWORD')
        )
        quote = await client.query('HSX:VNM')
        print(f"Price: {quote.latest_matched_price}")

Example (Kafka):
    from paperbroker.market_data import KafkaMarketDataClient
    
    async def main():
        client = KafkaMarketDataClient(
            bootstrap_servers=os.getenv('MARKET_KAFKA_BOOTSTRAP_SERVERS'),
            username=os.getenv('MARKET_KAFKA_USERNAME'),
            password=os.getenv('MARKET_KAFKA_PASSWORD')
        )
        
        def on_quote(instrument, quote):
            print(f"{instrument}: {quote.latest_matched_price}")
        
        await client.subscribe('HNXDS:VN30F2511', on_quote)
        await client.start()
"""

from .redis_client import RedisMarketDataClient
from .kafka_client import KafkaMarketDataClient
from .quote import QuoteSnapshot

__all__ = [
    "RedisMarketDataClient",
    "KafkaMarketDataClient",
    "QuoteSnapshot",
]
